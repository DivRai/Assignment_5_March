/* Create a class called 'Matrix' containing a constructor that initialises the number of rows and the
number of columns of a new Matrix object. The Matrix class has the following information:
1 - number of rows of matrix
2 - number of columns of matrix
3 - elements of matrix (You can use 2D vector)
The Matrix class has functions for each of the following:
1 - get the number of rows
2 - get the number of columns
3 - set the elements of the matrix at a given position (i,j)
4 - adding two matrices.
5 - multiplying the two matrices
You can assume that the dimensions are correct for the multiplication and addition. */

#include<iostream>
using namespace std;

class Matrix{

	public:
		int r, c;
		int **mat;

		Matrix() 	
		{ }
		
		Matrix(int R, int C)
		{
			r = R;
			c = C;
		
			//Dynamic Allocation of 2-D Array using new operator
			mat = new int*[r];
			for(int i=0; i<R; i++)
			{
				mat[i] = new int[C];
			}
		}

		void setEle(int i, int j, int val)
		{
			mat[i][j] = val;
		}

		Matrix Add(Matrix mat1, Matrix mat2)
		{
			Matrix mat3(mat1.r, mat1.c);
			int i,j;
			for(i=0;i<mat3.r;i++)
			{
				for(j=0;j<mat3.c;j++)
				{
					mat3.mat[i][j] = mat1.mat[i][j] + mat2.mat[i][j];
				}
			}
			return mat3;
		}

		Matrix Multiply(Matrix mat1, Matrix mat2)
		{
			Matrix mat3(mat1.r, mat2.c);
			int i,j,k;
			for(i=0;i<mat1.r;i++)
			{
				for(j=0;j<mat2.c;j++)
				{
					mat3.mat[i][j]=0;
					for(k=0;k<mat1.c;k++)
						mat3.mat[i][j] += mat1.mat[i][k] * mat2.mat[k][j];
				}
			}
			return mat3;
		}

		void Print()
		{
			int i,j;
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					cout << mat[i][j] << " ";
				}
				cout << endl;
			}
		}
};

int main()
{
	Matrix mat1(2,2);
	Matrix mat2(2,2);
	Matrix mat3;

	mat1.setEle(0,0,1);
	mat1.setEle(0,1,2);
	mat1.setEle(1,0,0);
	mat1.setEle(1,1,2);
	
	mat2.setEle(0,0,0);
	mat2.setEle(0,1,1);
	mat2.setEle(1,0,2);
	mat2.setEle(1,1,1);

	cout << "Matrix-1" <<endl;
	mat1.Print();

	cout << "\nMatrix-2" <<endl;
	mat2.Print();

	cout << "\nSum" <<endl;
	mat3 = mat3.Add(mat1,mat2);
	mat3.Print();

	cout << "\nProduct" <<endl;
	mat3 = mat3.Multiply(mat1,mat2);
	mat3.Print();
}

