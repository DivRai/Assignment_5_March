/* Print all nodes of a perfect binary tree in a specific order.
Given a perfect binary tree, print the values of alternating left and right nodes for each level in a
top-down and bottom-up manner.
For example, there are two ways to print the following tree:
Variation 1: Print Top-Down
(1, 2, 3, 4, 7, 5, 6, 8, 15, 9, 14, 10, 13, 11, 12)
Variation 2: Print Bottom-Up
(8, 15, 9, 14, 10, 13, 11, 12, 4, 7, 5, 6, 2, 3, 1) */

#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *lptr;
	struct node *rptr;
};

struct node *root=NULL;
struct node *Queue[10];
int front=-1, rear=-1;

int stack[20];
int top=-1;

void topDown();
void bottomUp();
struct node * CreateNode(int);
void enque(struct node *);
struct node * deque();
void PUSH(int);
int POP();

void main()
{
	struct node *parent;
	root = CreateNode(1);
	root->lptr = CreateNode(2);
	root->rptr = CreateNode(3);

	parent=root->lptr;
	parent->lptr = CreateNode(4);
	parent->rptr = CreateNode(5);

	parent=root->rptr;
	parent->lptr = CreateNode(6);
	parent->rptr = CreateNode(7);

	parent=root->lptr->lptr;
	parent->lptr = CreateNode(8);
	parent->rptr = CreateNode(9);

	parent=root->lptr->rptr;
	parent->lptr = CreateNode(10);
	parent->rptr = CreateNode(11);

	parent=root->rptr->lptr;
	parent->lptr = CreateNode(12);
	parent->rptr = CreateNode(13);

	parent=root->rptr->rptr;
	parent->lptr = CreateNode(14);
	parent->rptr = CreateNode(15);

	printf("Top Down: \n");
	topDown();

	printf("\n\nBottom Up: \n");
	bottomUp();

	printf("\n");

}

//Function to print Top Down in the specified order
void topDown()
{
	struct node *LEFT=NULL, *RIGHT=NULL;

	if(root==NULL)
	{
		printf("\nTree is Empty");
		return;
	}

	printf("%d ",root->data);

	if(root->lptr!=NULL)
	{
		printf("%d ",(root->lptr)->data);
		printf("%d ",(root->rptr)->data);
	}

	if((root->lptr)->lptr!=NULL)
	{
		enque(root->lptr);
		enque(root->rptr);
	}
	else
		return;

	while(front!=-1)
	{
		LEFT=deque();
		RIGHT=deque();

		printf("%d ",(LEFT->lptr)->data);
		printf("%d ",(RIGHT->rptr)->data);
		printf("%d ",(LEFT->rptr)->data);
		printf("%d ",(RIGHT->lptr)->data);

		if((LEFT->lptr)->lptr != NULL)
		{
			enque(LEFT->lptr);
			enque(RIGHT->rptr);
			enque(LEFT->rptr);
			enque(RIGHT->lptr);
		}
	}
}

//Function to print Bottom Up in the specified order
void bottomUp()
{
	struct node *LEFT=NULL, *RIGHT=NULL;

	if(root==NULL)
	{
		printf("\nTree is Empty");
		return;
	}

	PUSH(root->data);

	if(root->lptr!=NULL)
	{
		PUSH((root->rptr)->data);
		PUSH((root->lptr)->data);
	}

	if((root->lptr)->lptr!=NULL)
	{
		enque(root->rptr);
		enque(root->lptr);
	}
	else
		return;

	while(front!=-1)
	{
		RIGHT=deque();
		LEFT=deque();

		PUSH((RIGHT->lptr)->data);
		PUSH((LEFT->rptr)->data);
		PUSH((RIGHT->rptr)->data);
		PUSH((LEFT->lptr)->data);

		if((LEFT->lptr)->lptr != NULL)
		{
			enque(RIGHT->lptr);
			enque(LEFT->rptr);
			enque(RIGHT->rptr);
			enque(LEFT->lptr);
		}
	}

	while(top!=-1)
	{
		printf("%d ",POP());
	}
}

struct node * CreateNode(int x)
{
	struct node *New;
	New = (struct node *)malloc(sizeof(struct node));
	if(New==NULL)
	{
		printf("\nMemory Unavailable\n");
		return NULL;
	}
	else
	{
		New->data = x;
		New->lptr = NULL;
		New->rptr = NULL;
		return New;
	}
}

//Enque function definition
void enque(struct node *n)
{
	if(rear>=9)
	{
		printf("\nQueue Overflow!");
	}
	else
	{	
		rear=rear+1;
		Queue[rear]=n;
		
		if(front==-1)
			front=front+1;
	}
}

//Deque function definition
struct node * deque()
{
	if(front==-1)
	{
		printf("\nQueue Underflow!");
		return NULL;
	}
	else
	{
		struct node *temp=Queue[front];
		if(front==rear)
		{
			front=-1;
			rear=-1;
		}
		else
			front=front+1;
		
		return temp;
	}
}

void PUSH(int x)
{
	if(top==19)
	{
		printf("\nStack OVerflow");
		return;
	}

	top=top+1;
	stack[top]=x;
}

int POP()
{
	if(top==-1)
	{
		printf("\nStack Underflow");
		return 0;
	}

	top=top-1;

	return stack[top+1];
}

